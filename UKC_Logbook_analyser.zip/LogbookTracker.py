"""
Author:     Alistair Lee
Goal:       A place to start investigating the climbs undertaken by the climbers
Created:    06/03/2020

NB: To add more climbers to this:
    - Download your logbook from ukclimbing.com -> my logbook
    - Find and replace all instances of β for Flash
    - Save the file as a .csv in Logbooks
    - Add static information about the new climber to the csv in Climbers\\Climbers.csv

"""
from ClimberManager import ClimberManager

climber_tracker = ClimberManager()

climber = climber_tracker.get_climber('Alistair Lee')

print(climber.get_routes_climbed())
print(climber.get_climbs_done())

print(climber.get_logbook()[0].get_date(), '\n',
      climber.get_logbook()[0].get_climb().get_name(), '\n',
      climber.get_logbook()[0].get_notes())
