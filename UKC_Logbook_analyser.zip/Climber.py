"""
Author:     Alistair Lee
Goal:       A climber object, holding all information about a climber
Created:    06/03/2020
"""
from ClimbManager import ClimbManager as cm


class Climber:
    """
    A climber object, holding all information about a climber
    """

    def __init__(self, first_name: str, last_name: str, ukc_name: str, age: int,
                 height: float, weight: float, sex: str, nationality: str):
        """
        When defining a climber pass all essential information about a climber

        :param first_name: First (given) name of a climber
        :param last_name: Last (family) name of a climber
        :param ukc_name: The username on UKC
        :param age: The age of a climber, int  # years
        :param height: The height of a climber, float  # cm
        :param weight: The weight of a climber, float  # kg
        :param sex: The sex of a climber, M/F
        :param nationality: The nationality of a climber
        """
        self._first_name = first_name
        self._last_name = last_name
        self._ukc_name = ukc_name
        self._age = age  # years
        self._height = height  # cm
        self._weight = weight  # kg
        self._sex = sex  # M/F
        self._nationality = nationality
        self._climbs = cm()

    def get_first_name(self) -> str:
        return self._first_name

    def get_last_name(self) -> str:
        return self._last_name

    def get_ukc_name(self) -> str:
        return self._ukc_name

    def get_age(self) -> int:
        return self._age

    def get_height(self) -> float:
        return self._height

    def get_weight(self) -> float:
        return self._height

    def get_sex(self) -> str:
        return self._sex

    def get_nationality(self) -> str:
        return self._nationality

    def get_name(self) -> str:
        """
        Return the full name of a climber, an addition of their first name and last name

        :return: Full name, str
        """
        return self.get_first_name().capitalize() + ' ' + self.get_last_name()

    def get_climb_manager(self) -> cm:
        return self._climbs

    def load_climbs(self):
        """
        Load all climbs for this climber, using their UKC logbook.

        :return: Climbs loaded
        """
        self.get_climb_manager().load_climbs(self.get_ukc_name())

    def get_climbs(self):
        """
        Get the climbs the climber has done

        :return: Set of Climb objects
        """
        return self.get_climb_manager().get_climbs()

    def get_logbook(self):
        """
        Get the logbook of climbs the climber has done

        :return: List of Log objects
        """
        return self.get_climb_manager().get_logbook()

    def get_routes_climbed(self):
        """
        Return the number of routes the user has done.

        :return: Number of routes the climber has completed
        """
        return len(self.get_climbs())

    def get_climbs_done(self):
        """
        Return the number of instances of climbs the climber has done

        :return: Total length of the logbook
        """
        return len(self.get_logbook())
