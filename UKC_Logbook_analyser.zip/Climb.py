"""
Author:     Alistair Lee
Goal:       A climb object, holding all information about a climb
Created:    06/03/2020
"""


class Climb:
    """
    A climb object containing all information about a climb
    """

    def __init__(self, name: str, style: str, grade: str, stars, crag: str):
        """
        When defining the object pass all the essential information to the object.

        :param name: Name of the climb
        :param style: Style of the route, e.g. trad, sport, winter etc.
        :param grade: Grade of the route #TODO further define this so it is numeric
        :param stars: The amount of stars a route gets, maximum is 4
        :param crag: The crag the route is on
        """
        self._name = name
        self._style = style
        self._grade = grade
        self._stars = stars
        self._crag = crag

    def set_name(self, name):
        self._name = name

    def set_style(self, style):
        self._style = style

    def set_grade(self, grade):
        self._grade = grade

    def set_stars(self, stars):
        self._stars = stars

    def set_crag(self, crag):
        self._crag = crag

    def get_name(self) -> str:
        return self._name

    def get_style(self) -> str:
        return self._style

    def get_grade(self) -> str:
        return self._grade

    def get_stars(self) -> int:
        return self._stars

    def get_crag(self) -> str:
        return self._crag

    def name_crag(self) -> str:
        """
        Seeing as there are multiple routes of the same name at different crags it is worth making a unique identifier
        for each route, the route name + crag is sufficient.

        :return: Route name and crag
        """
        return self.get_name() + '_' + self.get_crag()
